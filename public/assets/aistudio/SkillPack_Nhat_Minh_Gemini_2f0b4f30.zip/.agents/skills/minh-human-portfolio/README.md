# Minh Human Portfolio — custom Agent Skill

Skill hướng dẫn AI xây portfolio/landing page cho Nhật Minh theo hướng cá nhân, chân thật, có art direction riêng, 3D có chọn lọc và tối ưu mobile.

## Dùng với AI coding

1. Đưa thư mục `minh-human-portfolio` vào nơi lưu skills mà coding agent của bạn hỗ trợ.
2. Nói rõ trong prompt: **“Use the `minh-human-portfolio` skill and follow `PROMPT_MASTER — LANDING PAGE PORTFOLIO NHẬT MINH`.”**
3. Đính kèm file `minh_landingpage_prompt.md` (nằm ngoài thư mục skill trong gói ZIP) để AI có brief đầy đủ.
4. Thay các placeholder về Discord, email, project, giá, tính năng và hình demo bằng dữ liệu thật trước khi public.

Skill là bộ hướng dẫn cho AI, không tự thêm tính năng vào website và không thay thế việc chạy build/kiểm thử.
