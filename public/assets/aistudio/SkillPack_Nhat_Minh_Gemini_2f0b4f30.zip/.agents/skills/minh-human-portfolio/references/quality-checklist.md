# Pre-delivery QA checklist

## Content honesty
- [ ] Creator introduction says student/independent creator honestly.
- [ ] No invented reviews, customers, income, years of experience, awards, or traffic metrics.
- [ ] Mock projects are labeled Concept/Demo/Lab.
- [ ] Prices, warranties, revision counts, tool features, and compatibility are confirmed or explicitly left as editable placeholders.
- [ ] Discord/email/social links come from the owner.

## Design and UX
- [ ] Strong, intentional hero composition.
- [ ] Section rhythm varies; not every section is the same grid of rounded cards.
- [ ] Body copy contrast and font sizes are comfortable.
- [ ] Nav, menu, CTA, FAQ, form/contact and project actions work.
- [ ] No `href="#"` dead-end CTAs or empty links.

## Responsive and accessibility
- [ ] No horizontal scroll at 320–375px.
- [ ] Check tablet and desktop layouts.
- [ ] Keyboard focus visible and logical.
- [ ] Reduced-motion preference respected.
- [ ] Content remains usable if WebGL fails.
- [ ] No autoplay sound.

## Performance and delivery
- [ ] Heavy 3D/media lazy-loaded where suitable.
- [ ] No unnecessary continuously running render loop.
- [ ] Images use appropriate sizes and formats.
- [ ] Build/lint/typecheck run when available; failures reported honestly.
- [ ] Setup steps and editable config file documented.
