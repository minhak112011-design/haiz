---
name: minh-human-portfolio
description: Design, write, implement, and review a distinctive personal portfolio or freelancer landing page for a young student web creator. Use for Vietnamese creator portfolios, service landing pages, project showcases, digital-tool catalogs, anti-template design, tasteful 3D motion, responsive UI, and conversion-focused copy. Avoid invented credentials, fake testimonials, broken CTAs, and performance-heavy animation.
---

# Minh Human Portfolio Skill

## Purpose

Create a credible, distinct portfolio landing page for Nhật Minh, a student who builds custom websites and presents digital tools. Make it feel authored by a real young creator rather than a generic AI template. Treat honesty, readability, mobile usability, and clear contact paths as design requirements.

## Required workflow

1. Inspect the existing project before changing files. Identify framework, package manager, versions, routes, components, styling conventions, and available scripts. Preserve working code unless the change is justified.
2. Define an art direction before implementation: audience, one-sentence concept, palette with 4–6 named colors, typography, layout rhythm, hero signature, motion principles, and anti-patterns intentionally avoided.
3. Write real, specific Vietnamese microcopy. Use a warm, direct, modest voice. The creator is a student and must not be presented as a senior agency, experienced expert, or proven business unless the user supplies evidence.
4. Build the entire page, not only the hero or a static mockup. Every visible button, link, menu item, FAQ control, and contact action must work or clearly indicate what needs configuration.
5. Perform a design critique and functional verification. Fix obvious issues before handoff.

## Content model

Include as appropriate:
- Hero: who the creator is, what they build, and a primary contact CTA.
- About: personal motivation, current student status, realistic working style.
- Services: personal/gift websites, profile or group websites, and custom landing pages.
- Work: real projects only when verified. Label uncommissioned mockups as “Concept”, “Demo”, or “Lab”. Never fabricate clients, reviews, traffic numbers, sales, or outcomes.
- Digital tools: for Discord utilities and Hook MB, use owner-supplied feature names, versions, compatibility, pricing, support terms, and demo media. Leave conspicuous editable placeholders for unknown facts. Never claim universal compatibility or unverified capabilities.
- Process: idea intake, scope, first draft, review, handoff. Avoid inventing turnaround times, revision limits, warranties, or payment terms.
- FAQ and contact: practical answers, contact destinations from configuration, and no dead links. The verified primary contact for website orders is Nhật Minh’s Facebook profile: https://www.facebook.com/profile.php?id=61594074891915&locale=vi_VN. Include a clear “Inbox Facebook để đặt làm web” CTA in the hero/contact section and a Facebook link in the footer.

## Copywriting rules

- Prefer conversational Vietnamese with concrete nouns and active verbs.
- Keep headline specific to the creator. Example direction: “Bạn có ý tưởng. Mình giúp nó thành một chiếc web thật.”
- Be candid that the owner is a student who is learning and taking on suitable projects.
- Make the CTA describe the next action: “Trao đổi ý tưởng”, “Xem concept”, or “Đặt làm website”.
- Avoid filler such as “nâng tầm thương hiệu”, “giải pháp toàn diện”, “đẳng cấp hàng đầu”, “công nghệ tiên tiến” unless supported and genuinely relevant.
- Do not create artificial urgency, fake scarcity, fake social proof, or fabricated pricing.
- Do not autoplay sound. For gift websites, use photos, music, and video only when the owner/customer supplies them or has permission to use them.

## Visual quality bar

- Choose one strong art direction based on the brief; do not blindly default to a common AI portfolio style.
- Use deliberate typography, spacing, asymmetric composition, varied section rhythm, readable contrast, and a distinct hero visual.
- Dark digital-studio aesthetics may use near-black, graphite, soft white, electric cyan, and a restrained secondary accent. Treat these as a starting point, not a rigid requirement.
- Avoid indiscriminate purple gradients, random blurred blobs, repetitive rounded-card grids, excessive glassmorphism, constant scroll reveals, nonstop marquees, overused pill badges, tiny text, and strong glow behind body copy.
- Every animation must communicate hierarchy, depth, state, or response. Use one orchestrated reveal rather than animating everything.

## 3D and motion performance

1. Use a single signature 3D element when it materially improves the concept.
2. Use CSS 3D, SVG, or layered elements for lightweight depth. Use Three.js/React Three Fiber only when real 3D interaction justifies the dependency.
3. Lazy-load 3D and heavy media; provide a static fallback; limit pixel ratio, geometry, texture size, shader cost, and unnecessary frame loops.
4. Keep core copy and CTA outside the 3D canvas so the page remains usable when WebGL fails.
5. Respect `prefers-reduced-motion`; reduce parallax and scroll-linked movement on mobile or low-power contexts. Never hijack scrolling.
6. Favor transform and opacity for simple motion; profile before adding extra libraries.

## Responsive and accessibility checklist

- Check 320, 375, 768, 1024, and 1440 CSS-pixel widths or the closest available viewports.
- Prevent horizontal overflow. Keep headings responsive and buttons easy to tap.
- Use semantic HTML, ordered headings, visible keyboard focus, usable keyboard navigation, appropriate labels, meaningful image alt text, and readable color contrast.
- Do not rely only on color, hover, or cursor effects to expose information.
- Respect reduced motion and preserve content if animation or WebGL is unavailable.
- Avoid autoplay audio and unnecessary permission requests.

## Engineering rules

- For a new static portfolio, prefer a simple, lightweight stack such as React + TypeScript + Vite + Tailwind when suitable. Use the project's existing stack if it is healthy. Choose Next.js only when routing, SSR, or deployment requirements justify it.
- Use one primary animation system, not multiple overlapping libraries without a clear reason.
- Centralize contact links and editable business data in a configuration file. Set the confirmed Facebook URL to `https://www.facebook.com/profile.php?id=61594074891915&locale=vi_VN`; do not replace it with a placeholder or invent a different profile URL.
- Keep reusable sections/components readable and maintainable.
- Include metadata/title/description/Open Graph where practical.
- Do not expose private keys or secrets in browser code.
- Avoid placeholder links such as `href="#"` for final CTAs. If contact information is missing, make the configuration point obvious and tell the owner.

## Verification and handoff

Before finishing:
- Run available lint, type-check, build, or test commands.
- If browser tooling is available, verify page rendering, mobile menu, project links, FAQ, contact CTAs, keyboard focus, and narrow viewport behavior.
- Inspect the console and network failures when possible.
- Ensure reduced-motion behavior and 3D fallback are accounted for.
- Never claim a check passed if it was not run. State unverified items honestly.
- Report changed files, run instructions, content/URL placeholders, and any remaining problems.

## Final self-review questions

1. Could this be mistaken for a generic AI template? What one detail proves a specific design point of view?
2. Is the first screen immediately clear about who the creator is and what people can request?
3. Is every claim about experience, results, tools, pricing, and support grounded in owner-provided facts?
4. Is the site still attractive and usable without 3D or motion?
5. Are all main links and CTAs real and functional?
