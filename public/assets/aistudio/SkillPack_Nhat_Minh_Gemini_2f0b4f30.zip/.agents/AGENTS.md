# Project instructions — Nhật Minh portfolio

For requests involving the personal portfolio/landing page, first read and follow `.agents/skills/minh-human-portfolio/SKILL.md` and its quality checklist. Then read `PROMPT_MASTER.md` for the full website brief.

Build a complete, working website rather than a static mockup. Preserve the existing project structure and working code. Before coding, inspect the repository and describe the design direction briefly, then continue implementation without waiting for approval. Use natural Vietnamese copy, truthful placeholders, distinctive art direction, purposeful 3D/motion, responsive layouts and performance/accessibility fallbacks. Never invent customer testimonials, metrics, pricing, product features, links, or credentials. Test what the environment allows and clearly report what has not been tested.


Primary contact CTA: include “Inbox Facebook để đặt làm web” and use this exact URL: https://www.facebook.com/profile.php?id=61594074891915&locale=vi_VN. Add the link to the contact section and footer; do not invent another Facebook profile.
